Perfect Digital Contact Hub V2

GitHub/Vercel တင်နည်း
1. Repository ထဲရှိ index.html ကို ဒီ index.html ဖြင့် အစားထိုးပါ။
2. Commit changes လုပ်ပါ။
3. Vercel က အလိုအလျောက် Redeploy လုပ်ပါမည်။

ပါဝင်သော Functions
- Professional digital business card
- Profile photo upload
- Company / title / about
- Facebook / Telegram / Viber / Website
- KBZ / WavePay / AYA Pay
- vCard QR / VCF download / share
- QR PNG download
- Camera and image QR scanner
- Local analytics
- Dark mode
- Backup / restore
- Add to Home Screen support

မှတ်ချက်
- Login, Firebase cloud database နှင့် real multi-user analytics မပါသေးပါ။
- လက်ရှိ version သည် browser LocalStorage အသုံးပြုသော single-user version ဖြစ်ပါသည်။
