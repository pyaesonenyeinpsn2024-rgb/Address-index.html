Contact QR Manager - Full Version

အသုံးပြုနည်း
1. GitHub repository ထဲက index.html ကို ဒီ index.html နဲ့ အစားထိုးပါ။
2. Commit changes လုပ်ပါ။
3. Vercel က Auto Redeploy လုပ်ပါမယ်။
4. Website ကို HTTPS ဖြင့်ဖွင့်ပါ။

ပါဝင်သော Functions
- Multiple contacts
- Search / Sort
- Favorite
- Add / Edit / Delete
- vCard QR
- VCF Download / Share
- QR PNG Download
- Camera / Image QR Scanner
- CSV Import / Export
- JSON Backup / Restore
- Dark Mode
- LocalStorage
