Northern World Digital Card Maker V5

Features:
- Multiple customer cards
- QR and VCF
- WeChat, WhatsApp, Instagram and payments
- Templates
- Active/suspended and payment status
- Duplicate/delete
- Standalone HTML export
- JSON backup

Important: the manager stores cards in this browser only. Public links on other phones require either exporting each standalone HTML card and deploying it, or connecting Firebase/Supabase.
