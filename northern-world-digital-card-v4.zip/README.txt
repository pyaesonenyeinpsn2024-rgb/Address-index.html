Northern World Digital Business Card V4

1. Upload index.html to your GitHub repository and replace the old index.html.
2. Commit changes.
3. GitHub Pages / Vercel will redeploy automatically.
4. Open Admin. Default PIN: 4545.
5. Re-upload Profile Photo, Cover Photo and Company Logo.
6. Existing browser LocalStorage data uses the same V3 keys, so profile/catalog data should remain on the same browser/domain.

Important:
- Cover and logo images are stored inside browser LocalStorage.
- Use compressed JPG/WebP images under 4 MB.
